import pygame
import random
import os

# Set up the game window
WINDOW_SIZE = (800, 600)
pygame.init()
screen = pygame.display.set_mode(WINDOW_SIZE)
pygame.display.set_caption("PICO-9 BETA 1.0 FLAMES LLC 20XX")

# Set up the game objects
voxel_size = 20
world_size = (20, 20, 10)
world = [[[random.choice((0, 1)) for z in range(world_size[2])] for y in range(world_size[1])] for x in range(world_size[0])]
textures = {}

# Get the current directory of the .py file
current_dir = os.path.dirname(os.path.abspath(__file__))

# Load textures from files in the current directory
for filename in os.listdir(current_dir):
    if os.path.isfile(os.path.join(current_dir, filename)):
        try:
            texture = pygame.image.load(os.path.join(current_dir, filename)).convert_alpha()
            texture_name, extension = os.path.splitext(filename)
            if extension in ('.png', '.jpg', '.jpeg'):
                if 'stone' in texture_name:
                    textures['stone'] = pygame.transform.scale(texture, (voxel_size, voxel_size))
                elif 'dirt' in texture_name:
                    textures['dirt'] = pygame.transform.scale(texture, (voxel_size, voxel_size))
        except pygame.error:
            pass

# Set up the game loop
clock = pygame.time.Clock()
while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    # Draw the world
    screen.fill((0, 0, 0))
    for x in range(world_size[0]):
        for y in range(world_size[1]):
            for z in range(world_size[2]):
                if world[x][y][z]:
                    texture_name = 'stone' if random.random() < 0.5 else 'dirt'
                    if texture_name in textures:
                        texture = textures[texture_name]
                        x_pos = x * voxel_size
                        y_pos = y * voxel_size
                        z_pos = z * voxel_size
                        screen.blit(texture, (x_pos, y_pos + (world_size[2] - z - 1) * voxel_size, voxel_size, voxel_size))

    # Update the display
    pygame.display.update()

    # Cap the framerate
    clock.tick(60)
